package org.jfree.data.test;

import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeTest {
    private Range exampleRange;
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    }


    @Before
    public void setUp() throws Exception { exampleRange = new Range(-1, 1);
    }


    @Test
    public void centralValueShouldBeZero() {
        assertEquals("The central value of -1 and 1 should be 0",
        0, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    public void testContains() {
    	assertTrue("The contain method should return true because 0 is within the range -1 to 1",exampleRange.contains(0));
    }
    
    
    @Test
    public void testGetLowerBound() {
    	double expected=-1.0;
    	double actual=exampleRange.getLowerBound();
    	boolean condition=expected==actual;
    	assertTrue("GetLowerBound should return -1",condition);
    }
    
    @Test
    public void testGetUpperBound() {
    	double expected=1.0;
    	double actual=exampleRange.getUpperBound();

    	assertEquals("The upper bound should be 1",expected,actual,2);
    }
    
    @Test
    public void testGetLength() {
    	double expected=2.0;
    	double actual=exampleRange.getLength();
    	assertEquals("The length of exampleRange should be 2",expected,actual,2);
    }
    
    @Test
    public void testCombine() {
    	
    	Range range2=new Range(-5,-1);
    	Range actual=Range.combine(exampleRange, range2);
    	Range expected=new Range(-5,1);	
    	assertEquals("The combine method should return a range from -5 to 1",expected,actual);
    	
    }
    
    @Test
    public void testContains_LB_returnTrue() {
    	double LB=-1;
    	
    	assertTrue("Lower bound should be included in the range",exampleRange.contains(LB));
    }
    
    @Test
    public void testContains_ALB_returnTrue() {
    	double ALB=-0.5;
    	assertTrue("value above lower bound should be included in the range",exampleRange.contains(ALB));
    	
    }
    
    @Test
    public void testContains_BLB_returnFalse() {
    	double BLB=-2;
    	assertFalse("value below lower bound should not be included in the range",exampleRange.contains(BLB));
    	
    }
    
    @Test
    public void testContains_UB_returnTrue() {
    	double UB=1;
    	assertTrue("upper bound should be included in the range",exampleRange.contains(UB));
    	
    }
    
    @Test
    public void testContains_BUB_returnTrue() {
    	double BUB=0.5;
    	assertTrue("value below upper bound should be included in the range",exampleRange.contains(BUB));
    	
    }
    
    @Test
    public void testContains_AUB_returnFalse() {
    	double AUB=1.5;
    	assertFalse("value above upper bound should not be included in the range",exampleRange.contains(AUB));
    	
    }
    

    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
}

